let squarer;

function loadWebAssembly(fileName) {
    return fetch(fileName)
        .then(response => response.arrayBuffer())
        .then(bits => WebAssembly.compile(bits))
        .then(module => {
            console.log(module);
            return new WebAssembly.Instance(module)
        });
};

loadWebAssembly('_Z17wavelengthToColord.wasm')
    .then(instance => {
        squarer = instance.exports._Z17wavelengthToColord;
        //console.log('Finished compiling! Ready when you are...');

        for (let i = 380; i < 780; i++)
            console.log(squarer(i));
    });